<?php
/**
 * Static page template
 *
 * @package WP Basic Theme
 */

get_header();
?>

<main id="main-content" class="site-main">
    <div class="container">
        <?php wp_basic_breadcrumbs(); ?>

        <div class="content-area no-sidebar">
            <div id="primary" class="primary-content">
                <?php while ( have_posts() ) : the_post(); ?>

                    <article id="page-<?php the_ID(); ?>" <?php post_class(); ?>>

                        <header class="entry-header">
                            <?php if ( ! is_front_page() ) : ?>
                                <h1 class="entry-title"><?php the_title(); ?></h1>
                            <?php endif; ?>
                        </header>

                        <?php if ( has_post_thumbnail() && ! is_front_page() ) : ?>
                            <div class="entry-feature-image" style="margin-bottom:2rem;border-radius:var(--radius-lg);overflow:hidden;">
                                <?php the_post_thumbnail( 'wp-basic-hero', [ 'alt' => get_the_title() ] ); ?>
                            </div>
                        <?php endif; ?>

                        <div class="entry-content">
                            <?php
                            the_content();
                            wp_link_pages( [
                                'before' => '<div class="page-links">' . __( 'Pages:', 'wp-basic-theme' ),
                                'after'  => '</div>',
                            ] );
                            ?>
                        </div>

                        <?php if ( get_edit_post_link() ) : ?>
                            <footer class="entry-footer">
                                <?php edit_post_link( __( 'Edit page', 'wp-basic-theme' ), '<span class="edit-link">', '</span>' ); ?>
                            </footer>
                        <?php endif; ?>

                    </article>

                    <?php if ( comments_open() || get_comments_number() ) : ?>
                        <div class="comments-area"><?php comments_template(); ?></div>
                    <?php endif; ?>

                <?php endwhile; ?>
            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>
