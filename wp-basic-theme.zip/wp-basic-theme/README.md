# WP Basic Theme

A clean, modern, fully-structured WordPress starter theme.

## Features

- Sticky glassmorphism header with custom logo, primary nav + mobile hamburger menu
- Responsive 4-column footer with widget areas + social icons
- Front-page hero, latest-posts grid
- Single-post reading time estimate, author bio, share links, tags
- Breadcrumb navigation (no plugin required)
- 4 registered widget areas (sidebar + 4 footer columns)
- 3 nav menus: Primary, Footer, Social
- Custom page templates: Full-Width, Blank Canvas
- Post format support (aside, gallery, image, link, quote, status, video)
- Open Graph / Twitter Card meta tags
- Customizer options: copyright text + 6 social link fields
- theme.json for block-editor colour palette + typography
- `WP_Basic_Walker_Nav_Menu` — aria-current, dropdown carets
- Performance helpers: emoji removal, query-string stripping, defer scripts

## File Structure

```
wp-basic-theme/
├── style.css               ← Theme header + all CSS
├── functions.php           ← Theme setup, enqueues, helpers, customizer
├── index.php               ← Blog / posts list
├── front-page.php          ← Homepage (hero + latest posts)
├── single.php              ← Single post
├── page.php                ← Static page
├── archive.php             ← Category / tag / date / author archives
├── search.php              ← Search results
├── 404.php                 ← Not-found page
├── sidebar.php             ← Primary sidebar
├── header.php              ← <head> + site header
├── footer.php              ← Footer + </html>
├── theme.json              ← Block editor settings
├── template-parts/
│   ├── content.php         ← Post card (standard loop)
│   ├── content-search.php  ← Post card for search results
│   └── content-none.php    ← "Nothing found" message
├── page-templates/
│   ├── full-width.php      ← Full-width page (no sidebar)
│   └── blank.php           ← Blank canvas (no header/footer)
├── inc/
│   ├── template-tags.php           ← Display helper functions
│   ├── template-functions.php      ← Hooks, OG tags, perf tweaks
│   └── class-walker-nav-menu.php   ← Custom nav walker
└── assets/
    └── js/
        ├── main.js          ← Mobile nav, smooth scroll, lazy-load
        └── customizer.js    ← Live-preview JS for Customizer
```

## Installation

1. Copy the `wp-basic-theme/` folder to your WordPress `wp-content/themes/` directory.
2. Go to **Appearance → Themes** and activate **WP Basic Theme**.
3. Assign menus at **Appearance → Menus** (Primary, Footer, Social).
4. Add widgets at **Appearance → Widgets** (Sidebar, Footer 1–4).
5. Configure social links at **Appearance → Customize → Social Links**.
