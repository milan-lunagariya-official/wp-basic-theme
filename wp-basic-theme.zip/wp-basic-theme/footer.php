<?php
/**
 * Footer template — loaded by get_footer()
 *
 * @package WP Basic Theme
 */
?>

    <!-- ===================== FOOTER ===================== -->
    <footer class="site-footer" id="colophon" role="contentinfo">
        <div class="container">

            <!-- Widget columns -->
            <div class="footer-widgets">

                <!-- Col 1: Brand / about -->
                <div class="footer-widget">
                    <?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-1' ); ?>
                    <?php else : ?>
                        <h3 class="footer-widget-title"><?php bloginfo( 'name' ); ?></h3>
                        <p style="font-size:.875rem;line-height:1.7;color:var(--color-footer-text);">
                            <?php bloginfo( 'description' ); ?>
                        </p>
                        <!-- Social icons -->
                        <?php wp_basic_footer_social_icons(); ?>
                    <?php endif; ?>
                </div>

                <!-- Col 2 -->
                <div class="footer-widget">
                    <?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-2' ); ?>
                    <?php else : ?>
                        <h3 class="footer-widget-title"><?php esc_html_e( 'Quick Links', 'wp-basic-theme' ); ?></h3>
                        <ul>
                            <?php wp_list_pages( [ 'title_li' => '', 'depth' => 1 ] ); ?>
                        </ul>
                    <?php endif; ?>
                </div>

                <!-- Col 3 -->
                <div class="footer-widget">
                    <?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-3' ); ?>
                    <?php else : ?>
                        <h3 class="footer-widget-title"><?php esc_html_e( 'Categories', 'wp-basic-theme' ); ?></h3>
                        <ul>
                            <?php wp_list_categories( [ 'title_li' => '', 'show_count' => true ] ); ?>
                        </ul>
                    <?php endif; ?>
                </div>

                <!-- Col 4 -->
                <div class="footer-widget">
                    <?php if ( is_active_sidebar( 'footer-4' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-4' ); ?>
                    <?php else : ?>
                        <h3 class="footer-widget-title"><?php esc_html_e( 'Recent Posts', 'wp-basic-theme' ); ?></h3>
                        <?php
                        $recent = new WP_Query( [ 'posts_per_page' => 4, 'no_found_rows' => true ] );
                        if ( $recent->have_posts() ) :
                            echo '<ul>';
                            while ( $recent->have_posts() ) : $recent->the_post(); ?>
                                <li>
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                    <br><small style="color:rgba(255,255,255,.35);"><?php echo get_the_date(); ?></small>
                                </li>
                            <?php endwhile;
                            echo '</ul>';
                            wp_reset_postdata();
                        endif;
                        ?>
                    <?php endif; ?>
                </div>

            </div><!-- .footer-widgets -->

            <!-- Bottom bar -->
            <div class="footer-bottom">
                <span class="copyright">
                    <?php
                    $copy = get_theme_mod(
                        'footer_copyright',
                        sprintf( '&copy; %d %s. All rights reserved.', date( 'Y' ), get_bloginfo( 'name' ) )
                    );
                    echo wp_kses_post( $copy );
                    ?>
                </span>

                <?php if ( has_nav_menu( 'footer' ) ) : ?>
                    <nav class="footer-nav" aria-label="<?php esc_attr_e( 'Footer Menu', 'wp-basic-theme' ); ?>">
                        <?php
                        wp_nav_menu( [
                            'theme_location' => 'footer',
                            'menu_class'     => 'footer-nav',
                            'container'      => false,
                            'depth'          => 1,
                            'fallback_cb'    => false,
                        ] );
                        ?>
                    </nav>
                <?php endif; ?>

                <span class="powered-by">
                    <?php
                    printf(
                        /* translators: %s: WordPress */
                        esc_html__( 'Powered by %s', 'wp-basic-theme' ),
                        '<a href="https://wordpress.org" target="_blank" rel="noopener noreferrer">WordPress</a>'
                    );
                    ?>
                </span>
            </div><!-- .footer-bottom -->

        </div><!-- .container -->
    </footer><!-- #colophon -->

</div><!-- .site-wrapper -->

<?php wp_footer(); ?>
</body>
</html>

<?php
/**
 * Render social icons from Customizer URLs.
 */
function wp_basic_footer_social_icons() {
    $networks = [
        'twitter'   => [ 'label' => 'Twitter / X',  'icon' => '𝕏' ],
        'facebook'  => [ 'label' => 'Facebook',      'icon' => 'f' ],
        'instagram' => [ 'label' => 'Instagram',     'icon' => '📷' ],
        'linkedin'  => [ 'label' => 'LinkedIn',      'icon' => 'in' ],
        'github'    => [ 'label' => 'GitHub',        'icon' => '⬡' ],
        'youtube'   => [ 'label' => 'YouTube',       'icon' => '▶' ],
    ];

    $has_any = false;
    foreach ( $networks as $key => $data ) {
        if ( get_theme_mod( "social_{$key}" ) ) { $has_any = true; break; }
    }

    if ( ! $has_any ) return;

    echo '<div class="social-links" style="margin-top:1rem;">';
    foreach ( $networks as $key => $data ) {
        $url = get_theme_mod( "social_{$key}" );
        if ( $url ) {
            printf(
                '<a href="%s" target="_blank" rel="noopener noreferrer me" aria-label="%s">%s</a>',
                esc_url( $url ),
                esc_attr( $data['label'] ),
                $data['icon']
            );
        }
    }
    echo '</div>';
}
