<?php
/**
 * Search results template
 *
 * @package WP Basic Theme
 */

get_header();
?>

<main id="main-content" class="site-main">

    <div class="page-hero">
        <div class="container">
            <h1>
                <?php
                printf(
                    esc_html__( 'Search Results: %s', 'wp-basic-theme' ),
                    '<em>' . get_search_query() . '</em>'
                );
                ?>
            </h1>
            <?php get_search_form(); ?>
        </div>
    </div>

    <div class="container" style="padding-top:2rem;">
        <?php wp_basic_breadcrumbs(); ?>

        <div class="content-area <?php echo is_active_sidebar( 'sidebar-1' ) ? '' : 'no-sidebar'; ?>">
            <div id="primary">
                <?php if ( have_posts() ) : ?>
                    <p style="color:var(--color-muted);margin-bottom:1.5rem;">
                        <?php
                        global $wp_query;
                        printf(
                            _n( 'Found %d result.', 'Found %d results.', $wp_query->found_posts, 'wp-basic-theme' ),
                            number_format_i18n( $wp_query->found_posts )
                        );
                        ?>
                    </p>
                    <div class="posts-grid">
                        <?php while ( have_posts() ) : the_post(); ?>
                            <?php get_template_part( 'template-parts/content', 'search' ); ?>
                        <?php endwhile; ?>
                    </div>
                    <?php wp_basic_numeric_pagination(); ?>
                <?php else : ?>
                    <?php get_template_part( 'template-parts/content', 'none' ); ?>
                <?php endif; ?>
            </div>

            <?php if ( is_active_sidebar( 'sidebar-1' ) ) get_sidebar(); ?>
        </div>
    </div>
</main>

<?php get_footer(); ?>
