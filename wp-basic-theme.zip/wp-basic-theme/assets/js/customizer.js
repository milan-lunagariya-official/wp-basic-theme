/**
 * Customizer live preview JS
 * Updates site title, tagline, and footer copyright in real time.
 */
(function($) {
    'use strict';

    wp.customize('blogname', function(value) {
        value.bind(function(newval) {
            $('.site-title a').text(newval);
        });
    });

    wp.customize('blogdescription', function(value) {
        value.bind(function(newval) {
            $('.site-description').text(newval);
        });
    });

    wp.customize('footer_copyright', function(value) {
        value.bind(function(newval) {
            $('.copyright').html(newval);
        });
    });

})(jQuery);
