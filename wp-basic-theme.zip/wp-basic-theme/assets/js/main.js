/**
 * Main JS for WP Basic Theme
 * Handles: mobile menu toggle, sub-menu toggle, sticky header, smooth scroll.
 */
(() => {
    'use strict';

    /* ── Mobile menu ──────────────────────────────────────── */
    const toggle  = document.getElementById('menu-toggle');
    const navMenu = document.querySelector('.nav-menu');

    if (toggle && navMenu) {
        toggle.addEventListener('click', () => {
            const expanded = toggle.getAttribute('aria-expanded') === 'true';
            toggle.setAttribute('aria-expanded', String(!expanded));
            navMenu.classList.toggle('is-open', !expanded);
        });

        // Sub-menu toggle on mobile
        navMenu.querySelectorAll('li').forEach(li => {
            const sub = li.querySelector('.sub-menu');
            if (!sub) return;

            const link = li.querySelector('a');
            if (!link) return;

            link.addEventListener('click', e => {
                if (window.innerWidth <= 900) {
                    e.preventDefault();
                    li.classList.toggle('is-open');
                }
            });
        });

        // Close on outside click
        document.addEventListener('click', e => {
            if (!toggle.contains(e.target) && !navMenu.contains(e.target)) {
                toggle.setAttribute('aria-expanded', 'false');
                navMenu.classList.remove('is-open');
            }
        });
    }

    /* ── Sticky header shadow ─────────────────────────────── */
    const header = document.getElementById('masthead');
    if (header) {
        const observeScroll = () => {
            header.style.boxShadow = window.scrollY > 10
                ? 'var(--shadow-md)'
                : 'var(--shadow-sm)';
        };
        window.addEventListener('scroll', observeScroll, { passive: true });
    }

    /* ── Smooth scroll for anchor links ──────────────────── */
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', e => {
            const target = document.querySelector(anchor.getAttribute('href'));
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                target.setAttribute('tabindex', '-1');
                target.focus({ preventScroll: true });
            }
        });
    });

    /* ── Lazy load images (IntersectionObserver) ─────────── */
    if ('IntersectionObserver' in window) {
        const io = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                    }
                    io.unobserve(img);
                }
            });
        }, { rootMargin: '200px' });

        document.querySelectorAll('img[data-src]').forEach(img => io.observe(img));
    }

    /* ── Back-to-top button ───────────────────────────────── */
    const btt = document.getElementById('back-to-top');
    if (btt) {
        window.addEventListener('scroll', () => {
            btt.style.opacity = window.scrollY > 400 ? '1' : '0';
            btt.style.pointerEvents = window.scrollY > 400 ? 'auto' : 'none';
        }, { passive: true });

        btt.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

})();
