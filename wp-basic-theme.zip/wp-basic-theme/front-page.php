<?php
/**
 * Front Page template  
 * Used when "A static page" is set as the front page in Reading Settings,
 * OR falls back to index.php for the latest-posts option.
 *
 * @package WP Basic Theme
 */

get_header();
?>

<main id="main-content" class="site-main">

    <!-- ───── HERO ───── -->
    <section class="page-hero" aria-labelledby="hero-heading">
        <div class="container">
            <h1 id="hero-heading" style="color:#fff;">
                <?php bloginfo( 'name' ); ?>
            </h1>
            <p>
                <?php bloginfo( 'description' ); ?>
            </p>
            <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;margin-top:2rem;">
                <a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ); ?>" class="btn btn-primary" style="background:#fff;color:var(--color-primary);">
                    <?php esc_html_e( 'Read the Blog', 'wp-basic-theme' ); ?>
                </a>
                <?php
                $contact_page = get_page_by_path( 'contact' );
                if ( $contact_page ) :
                ?>
                <a href="<?php echo esc_url( get_permalink( $contact_page ) ); ?>" class="btn btn-outline" style="border-color:rgba(255,255,255,.6);color:#fff;">
                    <?php esc_html_e( 'Get in Touch', 'wp-basic-theme' ); ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- ───── LATEST POSTS GRID ───── -->
    <section class="latest-posts" style="padding-block:4rem;">
        <div class="container">
            <h2 style="margin-bottom:2rem;"><?php esc_html_e( 'Latest Posts', 'wp-basic-theme' ); ?></h2>

            <?php
            $latest = new WP_Query( [
                'posts_per_page' => 6,
                'ignore_sticky_posts' => true,
            ] );
            if ( $latest->have_posts() ) :
            ?>
                <div class="posts-grid">
                    <?php while ( $latest->have_posts() ) : $latest->the_post(); ?>
                        <?php get_template_part( 'template-parts/content', get_post_format() ); ?>
                    <?php endwhile; ?>
                </div>
                <div style="text-align:center;margin-top:3rem;">
                    <a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ); ?>" class="btn btn-outline">
                        <?php esc_html_e( 'View All Posts', 'wp-basic-theme' ); ?>
                    </a>
                </div>
            <?php
            endif;
            wp_reset_postdata();
            ?>

        </div>
    </section>

    <!-- ───── FRONT PAGE CONTENT (if any) ───── -->
    <?php while ( have_posts() ) : the_post(); ?>
        <?php if ( get_the_content() ) : ?>
            <section class="front-page-content" style="padding-block:4rem;background:var(--color-surface);border-top:1px solid var(--color-border);">
                <div class="container">
                    <div class="entry-content" style="max-width:72ch;margin-inline:auto;">
                        <?php the_content(); ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    <?php endwhile; ?>

</main>

<?php get_footer(); ?>
