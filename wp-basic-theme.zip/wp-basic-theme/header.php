<?php
/**
 * Header template — loaded by get_header()
 *
 * @package WP Basic Theme
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php bloginfo( 'description' ); ?>">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#main-content">
    <?php esc_html_e( 'Skip to content', 'wp-basic-theme' ); ?>
</a>

<div class="site-wrapper">

    <!-- ===================== HEADER ===================== -->
    <header class="site-header" id="masthead" role="banner">
        <div class="container">
            <div class="header-inner">

                <!-- Branding -->
                <div class="site-branding">
                    <?php if ( has_custom_logo() ) : ?>
                        <?php the_custom_logo(); ?>
                    <?php else : ?>
                        <?php if ( is_front_page() && is_home() ) : ?>
                            <h1 class="site-title">
                                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                                    <?php bloginfo( 'name' ); ?>
                                </a>
                            </h1>
                        <?php else : ?>
                            <p class="site-title">
                                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                                    <?php bloginfo( 'name' ); ?>
                                </a>
                            </p>
                        <?php endif; ?>
                        <?php $description = get_bloginfo( 'description', 'display' ); ?>
                        <?php if ( $description || is_customize_preview() ) : ?>
                            <p class="site-description"><?php echo esc_html( $description ); ?></p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div><!-- .site-branding -->

                <!-- Primary Navigation -->
                <nav class="main-navigation" id="site-navigation" role="navigation"
                     aria-label="<?php esc_attr_e( 'Primary Menu', 'wp-basic-theme' ); ?>">

                    <button class="menu-toggle" id="menu-toggle"
                            aria-controls="primary-menu"
                            aria-expanded="false"
                            aria-label="<?php esc_attr_e( 'Toggle menu', 'wp-basic-theme' ); ?>">
                        ☰
                    </button>

                    <?php
                    wp_nav_menu( [
                        'theme_location' => 'primary',
                        'menu_id'        => 'primary-menu',
                        'menu_class'     => 'nav-menu',
                        'container'      => false,
                        'fallback_cb'    => 'wp_basic_primary_menu_fallback',
                    ] );
                    ?>
                </nav><!-- #site-navigation -->

            </div><!-- .header-inner -->
        </div><!-- .container -->
    </header><!-- #masthead -->

<?php
/**
 * Fallback menu — shows page list when no menu is assigned.
 */
function wp_basic_primary_menu_fallback() {
    echo '<ul id="primary-menu" class="nav-menu">';
    wp_list_pages( [
        'title_li' => '',
        'depth'    => 2,
    ] );
    echo '</ul>';
}
