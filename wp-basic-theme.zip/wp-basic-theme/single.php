<?php
/**
 * Single Post template
 *
 * @package WP Basic Theme
 */

get_header();
?>

<main id="main-content" class="site-main">
    <div class="container">
        <?php wp_basic_breadcrumbs(); ?>

        <div class="content-area <?php echo is_active_sidebar( 'sidebar-1' ) ? '' : 'no-sidebar'; ?>">

            <div id="primary" class="primary-content">
                <?php while ( have_posts() ) : the_post(); ?>

                    <article id="post-<?php the_ID(); ?>" <?php post_class( 'single-post' ); ?>>

                        <!-- Header -->
                        <header class="entry-header">
                            <div class="post-meta">
                                <?php wp_basic_category_badges(); ?>
                                <?php wp_basic_posted_on(); ?>
                                <?php wp_basic_posted_by(); ?>
                                <span class="reading-time">
                                    <?php
                                    $words   = str_word_count( strip_tags( get_the_content() ) );
                                    $minutes = max( 1, (int) ceil( $words / 200 ) );
                                    printf( _n( '%d min read', '%d min read', $minutes, 'wp-basic-theme' ), $minutes );
                                    ?>
                                </span>
                            </div>
                            <h1 class="entry-title"><?php the_title(); ?></h1>
                        </header>

                        <!-- Featured image -->
                        <?php if ( has_post_thumbnail() ) : ?>
                            <div class="entry-feature-image">
                                <?php the_post_thumbnail( 'wp-basic-hero', [ 'alt' => get_the_title() ] ); ?>
                            </div>
                        <?php endif; ?>

                        <!-- Body -->
                        <div class="entry-content">
                            <?php
                            the_content( sprintf(
                                wp_kses( __( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'wp-basic-theme' ), [ 'span' => [ 'class' => [] ] ] ),
                                get_the_title()
                            ) );
                            wp_link_pages( [
                                'before' => '<div class="page-links">' . __( 'Pages:', 'wp-basic-theme' ),
                                'after'  => '</div>',
                            ] );
                            ?>
                        </div>

                        <!-- Footer: tags + share -->
                        <footer class="entry-footer">
                            <?php if ( has_tag() ) : ?>
                                <div class="tag-links">
                                    <strong><?php esc_html_e( 'Tags:', 'wp-basic-theme' ); ?></strong>
                                    <?php the_tags( '', ' ', '' ); ?>
                                </div>
                            <?php endif; ?>

                            <div class="post-nav">
                                <?php
                                the_post_navigation( [
                                    'prev_text' => '&larr; %title',
                                    'next_text' => '%title &rarr;',
                                ] );
                                ?>
                            </div>
                        </footer>

                        <!-- Author Bio -->
                        <?php if ( get_the_author_meta( 'description' ) ) : ?>
                            <div class="author-bio" style="margin-top:2.5rem;padding:1.5rem;background:var(--color-bg);border-radius:var(--radius-lg);border:1px solid var(--color-border);display:flex;gap:1rem;align-items:flex-start;">
                                <?php echo get_avatar( get_the_author_meta( 'ID' ), 80, '', '', [ 'style' => 'border-radius:50%;flex-shrink:0;' ] ); ?>
                                <div>
                                    <h3 style="margin-bottom:.25rem;"><?php the_author(); ?></h3>
                                    <p style="color:var(--color-muted);font-size:.9rem;margin:0;"><?php the_author_meta( 'description' ); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>

                    </article>

                    <!-- Comments -->
                    <?php if ( comments_open() || get_comments_number() ) : ?>
                        <div class="comments-area">
                            <?php comments_template(); ?>
                        </div>
                    <?php endif; ?>

                <?php endwhile; ?>
            </div>

            <?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
                <?php get_sidebar(); ?>
            <?php endif; ?>

        </div>
    </div>
</main>

<?php get_footer(); ?>
