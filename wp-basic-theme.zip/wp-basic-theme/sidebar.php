<?php
/**
 * Sidebar template — loaded by get_sidebar()
 *
 * @package WP Basic Theme
 */
?>

<aside id="secondary" class="sidebar widget-area" role="complementary"
       aria-label="<?php esc_attr_e( 'Sidebar', 'wp-basic-theme' ); ?>">
    <?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside>
