<?php
/**
 * Main Index / Blog template
 *
 * @package WP Basic Theme
 */

get_header();
?>

<main id="main-content" class="site-main">
    <div class="container">

        <?php if ( is_home() && ! is_front_page() ) : ?>
            <div class="page-hero">
                <h1><?php single_post_title(); ?></h1>
            </div>
        <?php endif; ?>

        <?php wp_basic_breadcrumbs(); ?>

        <div class="content-area <?php echo is_active_sidebar( 'sidebar-1' ) ? '' : 'no-sidebar'; ?>">

            <!-- PRIMARY CONTENT -->
            <div id="primary" class="primary-content">

                <?php if ( have_posts() ) : ?>

                    <div class="posts-grid">
                        <?php while ( have_posts() ) : the_post(); ?>
                            <?php get_template_part( 'template-parts/content', get_post_format() ); ?>
                        <?php endwhile; ?>
                    </div>

                    <?php wp_basic_numeric_pagination(); ?>

                <?php else : ?>
                    <?php get_template_part( 'template-parts/content', 'none' ); ?>
                <?php endif; ?>

            </div><!-- #primary -->

            <!-- SIDEBAR -->
            <?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
                <?php get_sidebar(); ?>
            <?php endif; ?>

        </div><!-- .content-area -->
    </div><!-- .container -->
</main>

<?php
get_footer();

/**
 * Numeric pagination helper.
 */
function wp_basic_numeric_pagination() {
    global $wp_query;
    if ( $wp_query->max_num_pages <= 1 ) return;
    echo paginate_links( [
        'prev_text' => '&laquo; ' . __( 'Prev', 'wp-basic-theme' ),
        'next_text' => __( 'Next', 'wp-basic-theme' ) . ' &raquo;',
        'before_page_number' => '<span class="screen-reader-text">' . __( 'Page', 'wp-basic-theme' ) . ' </span>',
        'type'      => 'list',
    ] );
}
