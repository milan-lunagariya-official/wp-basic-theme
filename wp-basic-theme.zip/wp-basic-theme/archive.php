<?php
/**
 * Archive template (category, tag, date, author, etc.)
 *
 * @package WP Basic Theme
 */

get_header();
?>

<main id="main-content" class="site-main">

    <!-- Archive hero banner -->
    <div class="page-hero">
        <div class="container">
            <?php the_archive_title( '<h1>', '</h1>' ); ?>
            <?php the_archive_description( '<p>', '</p>' ); ?>
        </div>
    </div>

    <div class="container" style="padding-top:2rem;">
        <?php wp_basic_breadcrumbs(); ?>

        <div class="content-area <?php echo is_active_sidebar( 'sidebar-1' ) ? '' : 'no-sidebar'; ?>">

            <div id="primary" class="primary-content">
                <?php if ( have_posts() ) : ?>
                    <div class="posts-grid">
                        <?php while ( have_posts() ) : the_post(); ?>
                            <?php get_template_part( 'template-parts/content', get_post_format() ); ?>
                        <?php endwhile; ?>
                    </div>
                    <?php wp_basic_numeric_pagination(); ?>
                <?php else : ?>
                    <?php get_template_part( 'template-parts/content', 'none' ); ?>
                <?php endif; ?>
            </div>

            <?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
                <?php get_sidebar(); ?>
            <?php endif; ?>

        </div>
    </div>
</main>

<?php get_footer(); ?>
