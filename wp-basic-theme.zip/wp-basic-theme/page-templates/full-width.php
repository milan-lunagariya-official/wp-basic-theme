<?php
/**
 * Template: Page with Full-Width layout (no sidebar).
 * Select from "Page Attributes > Template" in the editor.
 *
 * Template Name: Full Width
 * @package WP Basic Theme
 */

get_header();
?>

<main id="main-content" class="site-main">
    <div class="container">
        <?php wp_basic_breadcrumbs(); ?>
        <div class="content-area no-sidebar">
            <div id="primary">
                <?php while ( have_posts() ) : the_post(); ?>
                    <article id="page-<?php the_ID(); ?>" <?php post_class(); ?>>
                        <header class="entry-header">
                            <h1 class="entry-title"><?php the_title(); ?></h1>
                        </header>
                        <?php if ( has_post_thumbnail() ) : ?>
                            <div style="margin-bottom:2rem;border-radius:var(--radius-lg);overflow:hidden;">
                                <?php the_post_thumbnail( 'wp-basic-hero', [ 'alt' => get_the_title() ] ); ?>
                            </div>
                        <?php endif; ?>
                        <div class="entry-content"><?php the_content(); ?></div>
                    </article>
                    <?php if ( comments_open() || get_comments_number() ) : ?>
                        <div class="comments-area"><?php comments_template(); ?></div>
                    <?php endif; ?>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>
