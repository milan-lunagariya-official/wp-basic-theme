<?php
/**
 * Template: Blank Canvas (no header/footer, no sidebar).
 * Useful for landing pages.
 *
 * Template Name: Blank Canvas
 * @package WP Basic Theme
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class('template-blank'); ?>>
<?php wp_body_open(); ?>

<div id="blank-page">
    <?php while ( have_posts() ) : the_post(); ?>
        <div class="entry-content"><?php the_content(); ?></div>
    <?php endwhile; ?>
</div>

<?php wp_footer(); ?>
</body>
</html>
