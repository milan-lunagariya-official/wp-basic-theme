<?php
/**
 * WP Basic Theme — functions.php
 * All theme setup, enqueues, custom functions, and hooks.
 */

defined( 'ABSPATH' ) || exit;

// ─────────────────────────────────────────────────────────────
// 1. THEME CONSTANTS
// ─────────────────────────────────────────────────────────────
define( 'WP_BASIC_VERSION', '1.0.0' );
define( 'WP_BASIC_DIR',     get_template_directory() );
define( 'WP_BASIC_URI',     get_template_directory_uri() );

// ─────────────────────────────────────────────────────────────
// 2. THEME SETUP
// ─────────────────────────────────────────────────────────────
if ( ! function_exists( 'wp_basic_setup' ) ) :
    function wp_basic_setup() {
        // Translations
        load_theme_textdomain( 'wp-basic-theme', WP_BASIC_DIR . '/languages' );

        // RSS feed links in <head>
        add_theme_support( 'automatic-feed-links' );

        // Custom <title> tag managed by WP
        add_theme_support( 'title-tag' );

        // Post thumbnails / featured images
        add_theme_support( 'post-thumbnails' );
        set_post_thumbnail_size( 800, 450, true );
        add_image_size( 'wp-basic-card',  600, 360, true );
        add_image_size( 'wp-basic-hero', 1600, 600, true );

        // HTML5 markup
        add_theme_support( 'html5', [
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        ] );

        // Custom logo
        add_theme_support( 'custom-logo', [
            'height'      => 80,
            'width'       => 200,
            'flex-height' => true,
            'flex-width'  => true,
        ] );

        // Post formats
        add_theme_support( 'post-formats', [
            'aside', 'gallery', 'image', 'link', 'quote', 'status', 'video',
        ] );

        // Selective refresh for widgets
        add_theme_support( 'customize-selective-refresh-widgets' );

        // Editor colour palette
        add_theme_support( 'editor-color-palette', [
            [ 'name' => 'Primary',   'slug' => 'primary',   'color' => '#2563eb' ],
            [ 'name' => 'Secondary', 'slug' => 'secondary', 'color' => '#7c3aed' ],
            [ 'name' => 'Accent',    'slug' => 'accent',    'color' => '#f59e0b' ],
        ] );

        // Register navigation menus
        register_nav_menus( [
            'primary'  => __( 'Primary Menu',  'wp-basic-theme' ),
            'footer'   => __( 'Footer Menu',   'wp-basic-theme' ),
            'social'   => __( 'Social Links',  'wp-basic-theme' ),
        ] );

        // Content width
        global $content_width;
        if ( ! isset( $content_width ) ) {
            $content_width = 800;
        }
    }
endif;
add_action( 'after_setup_theme', 'wp_basic_setup' );

// ─────────────────────────────────────────────────────────────
// 3. SCRIPTS & STYLES
// ─────────────────────────────────────────────────────────────
if ( ! function_exists( 'wp_basic_enqueue_assets' ) ) :
    function wp_basic_enqueue_assets() {
        // Google Fonts
        wp_enqueue_style(
            'wp-basic-google-fonts',
            'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap',
            [],
            null
        );

        // Main stylesheet
        wp_enqueue_style(
            'wp-basic-style',
            get_stylesheet_uri(),
            [ 'wp-basic-google-fonts' ],
            WP_BASIC_VERSION
        );

        // Main JS
        wp_enqueue_script(
            'wp-basic-main',
            WP_BASIC_URI . '/assets/js/main.js',
            [ 'jquery' ],
            WP_BASIC_VERSION,
            true  // footer
        );

        // Comments JS (only when needed)
        if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
            wp_enqueue_script( 'comment-reply' );
        }

        // Pass data to JS
        wp_localize_script( 'wp-basic-main', 'wpBasic', [
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'wp_basic_nonce' ),
            'siteUrl' => esc_url( home_url() ),
        ] );
    }
endif;
add_action( 'wp_enqueue_scripts', 'wp_basic_enqueue_assets' );

// ─────────────────────────────────────────────────────────────
// 4. SIDEBARS / WIDGET AREAS
// ─────────────────────────────────────────────────────────────
if ( ! function_exists( 'wp_basic_register_sidebars' ) ) :
    function wp_basic_register_sidebars() {
        $defaults = [
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h3 class="widget-title">',
            'after_title'   => '</h3>',
        ];

        register_sidebar( array_merge( $defaults, [
            'name'        => __( 'Primary Sidebar', 'wp-basic-theme' ),
            'id'          => 'sidebar-1',
            'description' => __( 'Shown on posts and pages.', 'wp-basic-theme' ),
        ] ) );

        register_sidebar( array_merge( $defaults, [
            'name'        => __( 'Footer Column 1', 'wp-basic-theme' ),
            'id'          => 'footer-1',
            'description' => __( 'First footer widget column.', 'wp-basic-theme' ),
        ] ) );

        register_sidebar( array_merge( $defaults, [
            'name'        => __( 'Footer Column 2', 'wp-basic-theme' ),
            'id'          => 'footer-2',
            'description' => __( 'Second footer widget column.', 'wp-basic-theme' ),
        ] ) );

        register_sidebar( array_merge( $defaults, [
            'name'        => __( 'Footer Column 3', 'wp-basic-theme' ),
            'id'          => 'footer-3',
            'description' => __( 'Third footer widget column.', 'wp-basic-theme' ),
        ] ) );

        register_sidebar( array_merge( $defaults, [
            'name'        => __( 'Footer Column 4', 'wp-basic-theme' ),
            'id'          => 'footer-4',
            'description' => __( 'Fourth footer widget column.', 'wp-basic-theme' ),
        ] ) );
    }
endif;
add_action( 'widgets_init', 'wp_basic_register_sidebars' );

// ─────────────────────────────────────────────────────────────
// 5. CUSTOM EXCERPT LENGTH & MORE LINK
// ─────────────────────────────────────────────────────────────
add_filter( 'excerpt_length', function() { return 25; } );
add_filter( 'excerpt_more',   function() {
    return '&hellip; <a class="read-more-link" href="' . get_permalink() . '">'
         . __( 'Read More', 'wp-basic-theme' ) . '</a>';
} );

// ─────────────────────────────────────────────────────────────
// 6. BODY CLASSES
// ─────────────────────────────────────────────────────────────
add_filter( 'body_class', function( $classes ) {
    if ( ! is_active_sidebar( 'sidebar-1' ) || is_page() ) {
        $classes[] = 'no-sidebar';
    }
    if ( is_singular() ) {
        $classes[] = 'single-view';
    }
    return $classes;
} );

// ─────────────────────────────────────────────────────────────
// 7. TEMPLATE TAGS HELPERS
// ─────────────────────────────────────────────────────────────

/**
 * Human-readable time ago.
 */
function wp_basic_posted_on() {
    $time = get_the_date( 'U' );
    $diff = human_time_diff( $time, current_time( 'timestamp' ) );
    $date = get_the_date();
    printf(
        '<time class="entry-date" datetime="%s" title="%s">%s</time>',
        esc_attr( get_the_date( 'c' ) ),
        esc_attr( $date ),
        esc_html( sprintf( __( '%s ago', 'wp-basic-theme' ), $diff ) )
    );
}

/**
 * Author with avatar.
 */
function wp_basic_posted_by() {
    printf(
        '<span class="byline">%s <a href="%s" rel="author">%s</a></span>',
        __( 'By', 'wp-basic-theme' ),
        esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
        esc_html( get_the_author() )
    );
}

/**
 * Category pills.
 */
function wp_basic_category_badges() {
    $cats = get_the_category();
    if ( ! $cats ) return;
    foreach ( $cats as $cat ) {
        printf(
            '<a href="%s" class="category-badge">%s</a>',
            esc_url( get_category_link( $cat->term_id ) ),
            esc_html( $cat->name )
        );
    }
}

/**
 * Simple breadcrumbs (no plugin required).
 */
function wp_basic_breadcrumbs() {
    if ( is_front_page() ) return;
    echo '<nav class="breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'wp-basic-theme' ) . '">';
    echo '<a href="' . esc_url( home_url() ) . '">' . __( 'Home', 'wp-basic-theme' ) . '</a>';
    echo '<span class="separator" aria-hidden="true">›</span>';
    if ( is_category() || is_single() ) {
        $cat = get_the_category();
        if ( $cat ) {
            echo '<a href="' . esc_url( get_category_link( $cat[0]->term_id ) ) . '">' . esc_html( $cat[0]->name ) . '</a>';
            echo '<span class="separator" aria-hidden="true">›</span>';
        }
    }
    if ( is_single() || is_page() ) {
        echo '<span class="current" aria-current="page">' . get_the_title() . '</span>';
    } elseif ( is_category() ) {
        echo '<span class="current">' . single_cat_title( '', false ) . '</span>';
    } elseif ( is_tag() ) {
        echo '<span class="current">' . single_tag_title( '', false ) . '</span>';
    } elseif ( is_search() ) {
        echo '<span class="current">' . sprintf( __( 'Search: %s', 'wp-basic-theme' ), get_search_query() ) . '</span>';
    } elseif ( is_404() ) {
        echo '<span class="current">' . __( '404 Not Found', 'wp-basic-theme' ) . '</span>';
    } elseif ( is_archive() ) {
        echo '<span class="current">' . get_the_archive_title() . '</span>';
    }
    echo '</nav>';
}

// ─────────────────────────────────────────────────────────────
// 8. CUSTOMIZER
// ─────────────────────────────────────────────────────────────
function wp_basic_customize_register( $wp_customize ) {
    // ── Footer ──
    $wp_customize->add_section( 'wp_basic_footer', [
        'title'    => __( 'Footer Settings', 'wp-basic-theme' ),
        'priority' => 130,
    ] );

    $wp_customize->add_setting( 'footer_copyright', [
        'default'           => sprintf( '© %d %s. All rights reserved.', date( 'Y' ), get_bloginfo( 'name' ) ),
        'sanitize_callback' => 'wp_kses_post',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'footer_copyright', [
        'label'   => __( 'Copyright Text', 'wp-basic-theme' ),
        'section' => 'wp_basic_footer',
        'type'    => 'textarea',
    ] );

    // ── Social ──
    $wp_customize->add_section( 'wp_basic_social', [
        'title'    => __( 'Social Links', 'wp-basic-theme' ),
        'priority' => 140,
    ] );

    $socials = [ 'twitter', 'facebook', 'instagram', 'linkedin', 'github', 'youtube' ];
    foreach ( $socials as $social ) {
        $wp_customize->add_setting( "social_{$social}", [
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
            'transport'         => 'refresh',
        ] );
        $wp_customize->add_control( "social_{$social}", [
            'label'   => ucfirst( $social ) . ' URL',
            'section' => 'wp_basic_social',
            'type'    => 'url',
        ] );
    }
}
add_action( 'customize_register', 'wp_basic_customize_register' );

// Selective refresh transport for title / tagline
add_action( 'customize_preview_init', function() {
    wp_enqueue_script(
        'wp-basic-customizer',
        WP_BASIC_URI . '/assets/js/customizer.js',
        [ 'customize-preview' ],
        WP_BASIC_VERSION,
        true
    );
} );

// ─────────────────────────────────────────────────────────────
// 9. ADD DEFER/ASYNC TO NON-CRITICAL SCRIPTS
// ─────────────────────────────────────────────────────────────
add_filter( 'script_loader_tag', function( $tag, $handle ) {
    $defer = [ 'wp-basic-main' ];
    if ( in_array( $handle, $defer, true ) ) {
        return str_replace( ' src', ' defer src', $tag );
    }
    return $tag;
}, 10, 2 );

// ─────────────────────────────────────────────────────────────
// 10. INCLUDE ADDITIONAL FILES
// ─────────────────────────────────────────────────────────────
foreach ( [
    '/inc/template-tags.php',
    '/inc/template-functions.php',
    '/inc/class-walker-nav-menu.php',
] as $file ) {
    $path = WP_BASIC_DIR . $file;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}
