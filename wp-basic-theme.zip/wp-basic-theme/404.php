<?php
/**
 * 404 Not Found template
 *
 * @package WP Basic Theme
 */

get_header();
?>

<main id="main-content" class="site-main">
    <div class="container">
        <div class="error-404" style="text-align:center;padding:5rem 0;">
            <div class="error-number">404</div>
            <h1><?php esc_html_e( 'Page Not Found', 'wp-basic-theme' ); ?></h1>
            <p style="color:var(--color-muted);max-width:480px;margin-inline:auto;">
                <?php esc_html_e( 'Oops! The page you\'re looking for doesn\'t exist or has been moved.', 'wp-basic-theme' ); ?>
            </p>
            <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;margin-top:2rem;">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-primary">
                    <?php esc_html_e( '← Back to Home', 'wp-basic-theme' ); ?>
                </a>
            </div>
            <div style="max-width:400px;margin:3rem auto 0;">
                <p style="font-weight:600;margin-bottom:.75rem;"><?php esc_html_e( 'Or try searching:', 'wp-basic-theme' ); ?></p>
                <?php get_search_form(); ?>
            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>
