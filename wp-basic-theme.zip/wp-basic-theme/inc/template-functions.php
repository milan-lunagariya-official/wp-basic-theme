<?php
/**
 * Template functions — non-display logic and hooks.
 *
 * @package WP Basic Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Add a pingback URL for single posts.
 */
function wp_basic_pingback_header() {
    if ( is_singular() && pings_open() ) {
        printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
    }
}
add_action( 'wp_head', 'wp_basic_pingback_header' );

/**
 * Remove emoji scripts for performance.
 */
function wp_basic_disable_emojis() {
    remove_action( 'wp_head',             'print_emoji_detection_script', 7 );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'wp_print_styles',     'print_emoji_styles' );
    remove_action( 'admin_print_styles',  'print_emoji_styles' );
    remove_filter( 'the_content_feed',    'wp_staticize_emoji' );
    remove_filter( 'comment_text_rss',    'wp_staticize_emoji' );
    remove_filter( 'wp_mail',            'wp_staticize_emoji_for_email' );
}
add_action( 'init', 'wp_basic_disable_emojis' );

/**
 * Remove query strings from static assets for caching.
 */
add_filter( 'script_loader_src', 'wp_basic_remove_query_strings' );
add_filter( 'style_loader_src',  'wp_basic_remove_query_strings' );
function wp_basic_remove_query_strings( $src ) {
    if ( strpos( $src, '?ver=' ) ) {
        $src = remove_query_arg( 'ver', $src );
    }
    return $src;
}

/**
 * Add Open Graph meta tags for the single post.
 */
function wp_basic_og_tags() {
    if ( ! is_singular() ) return;
    global $post;
    setup_postdata( $post );

    $title       = get_the_title();
    $description = has_excerpt() ? get_the_excerpt() : wp_trim_words( get_the_content(), 20 );
    $image       = has_post_thumbnail() ? get_the_post_thumbnail_url( null, 'large' ) : get_site_icon_url( 512 );
    $url         = get_permalink();
    ?>
    <meta property="og:type"        content="article">
    <meta property="og:title"       content="<?php echo esc_attr( $title ); ?>">
    <meta property="og:description" content="<?php echo esc_attr( $description ); ?>">
    <meta property="og:url"         content="<?php echo esc_url( $url ); ?>">
    <?php if ( $image ) : ?>
    <meta property="og:image"       content="<?php echo esc_url( $image ); ?>">
    <?php endif; ?>
    <meta name="twitter:card"       content="summary_large_image">
    <?php
    wp_reset_postdata();
}
add_action( 'wp_head', 'wp_basic_og_tags' );
