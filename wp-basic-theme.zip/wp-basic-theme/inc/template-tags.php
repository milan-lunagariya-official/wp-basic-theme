<?php
/**
 * Additional template tags.
 * Extends the scaffold in functions.php.
 *
 * @package WP Basic Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Render an SVG inline placeholder when no featured image exists.
 */
function wp_basic_post_placeholder() {
    echo '<div class="post-placeholder" style="width:100%;height:200px;background:linear-gradient(135deg,#eff6ff,#f0f9ff);display:flex;align-items:center;justify-content:center;">';
    echo '<span style="font-size:3rem;opacity:.3;">📝</span>';
    echo '</div>';
}

/**
 * Numeric pagination (also used by index.php / archive.php).
 * Safe to call multiple times — the function is already defined in index.php
 * only when the file is loaded; here we provide a global version.
 */
if ( ! function_exists( 'wp_basic_numeric_pagination' ) ) :
    function wp_basic_numeric_pagination() {
        global $wp_query;
        if ( $wp_query->max_num_pages <= 1 ) return;
        echo '<nav class="pagination" aria-label="' . esc_attr__( 'Posts pagination', 'wp-basic-theme' ) . '">';
        echo paginate_links( [
            'prev_text' => '&laquo;',
            'next_text' => '&raquo;',
            'type'      => 'plain',
        ] );
        echo '</nav>';
    }
endif;

/**
 * Print social share links for single posts.
 */
function wp_basic_share_links() {
    $url   = urlencode( get_permalink() );
    $title = urlencode( get_the_title() );
    ?>
    <div class="share-links" style="display:flex;gap:.75rem;flex-wrap:wrap;margin-top:1.5rem;">
        <span style="font-weight:600;align-self:center;"><?php esc_html_e( 'Share:', 'wp-basic-theme' ); ?></span>
        <a href="https://twitter.com/intent/tweet?url=<?php echo $url; ?>&text=<?php echo $title; ?>"
           target="_blank" rel="noopener noreferrer" class="btn btn-outline" style="padding:.4rem .9rem;font-size:.8rem;">
            Twitter
        </a>
        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $url; ?>"
           target="_blank" rel="noopener noreferrer" class="btn btn-outline" style="padding:.4rem .9rem;font-size:.8rem;">
            Facebook
        </a>
        <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo $url; ?>&title=<?php echo $title; ?>"
           target="_blank" rel="noopener noreferrer" class="btn btn-outline" style="padding:.4rem .9rem;font-size:.8rem;">
            LinkedIn
        </a>
    </div>
    <?php
}
