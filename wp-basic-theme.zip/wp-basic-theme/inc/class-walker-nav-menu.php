<?php
/**
 * Custom Walker for the primary nav menu.
 * Adds aria attributes and dropdown indicators.
 *
 * @package WP Basic Theme
 */

defined( 'ABSPATH' ) || exit;

class WP_Basic_Walker_Nav_Menu extends Walker_Nav_Menu {

    /**
     * Open <li>.
     */
    public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
        $classes   = empty( $item->classes ) ? [] : (array) $item->classes;
        $class_str = implode( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );

        $output .= '<li id="menu-item-' . absint( $item->ID ) . '" class="' . esc_attr( $class_str ) . '">';

        $atts = [];
        $atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
        $atts['target'] = ! empty( $item->target ) ? $item->target : '';
        $atts['rel']    = ! empty( $item->xfn ) ? $item->xfn : '';
        $atts['href']   = ! empty( $item->url ) ? $item->url : '';

        // Add aria-current
        if ( in_array( 'current-menu-item', $classes ) ) {
            $atts['aria-current'] = 'page';
        }

        $atts = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );

        $attr_str = '';
        foreach ( $atts as $attr => $value ) {
            if ( is_scalar( $value ) && '' !== $value && false !== $value ) {
                $attr_str .= ' ' . $attr . '="' . esc_attr( $value ) . '"';
            }
        }

        $title = apply_filters( 'the_title', $item->title, $item->ID );

        $output .= '<a' . $attr_str . '>' . esc_html( $title );

        // Dropdown caret for items that have children
        if ( $args->walker->has_children ) {
            $output .= ' <span class="dropdown-caret" aria-hidden="true">&#9662;</span>';
        }

        $output .= '</a>';
    }
}
