<?php
/**
 * Template part: No posts found.
 *
 * @package WP Basic Theme
 */
?>
<section class="no-results not-found" style="text-align:center;padding:4rem 0;">
    <h2><?php esc_html_e( 'Nothing Found', 'wp-basic-theme' ); ?></h2>
    <p style="color:var(--color-muted);">
        <?php
        if ( is_search() ) :
            esc_html_e( 'Sorry, no results matched your search. Try different keywords.', 'wp-basic-theme' );
        else :
            esc_html_e( 'It seems we can\'t find what you\'re looking for. Perhaps searching can help.', 'wp-basic-theme' );
        endif;
        ?>
    </p>
    <?php get_search_form(); ?>
</section>
