<?php
/**
 * Template part: Standard post card
 * Used for: index, archive, search, front-page loops.
 *
 * @package WP Basic Theme
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>

    <?php if ( has_post_thumbnail() ) : ?>
        <div class="post-thumbnail" style="overflow:hidden;">
            <a href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
                <?php the_post_thumbnail( 'wp-basic-card', [ 'alt' => '' ] ); ?>
            </a>
        </div>
    <?php endif; ?>

    <div class="post-card-body">
        <div class="post-meta">
            <?php wp_basic_category_badges(); ?>
            <?php wp_basic_posted_on(); ?>
        </div>

        <h2 class="entry-title">
            <a href="<?php the_permalink(); ?>" rel="bookmark">
                <?php the_title(); ?>
            </a>
        </h2>

        <div class="entry-summary">
            <?php the_excerpt(); ?>
        </div>

        <a href="<?php the_permalink(); ?>" class="read-more-link">
            <?php esc_html_e( 'Read More', 'wp-basic-theme' ); ?>
        </a>
    </div>

</article>
